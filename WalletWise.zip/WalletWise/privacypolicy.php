<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Privacy Policy - WalletWise</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 40px;
      background-color: #f8f9fa;
      color: #333;
    }
    .container {
      max-width: 800px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    h1 {
      color: #1a3d7c;
    }
    h2 {
      color: #1a3d7c;
      margin-top: 20px;
    }
    p {
      line-height: 1.6;
    }
    ul {
      margin-left: 20px;
    }
    strong {
      color: #000;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Privacy Policy</h1>
    <p><strong>App Name:</strong> WalletWise</p>
    <p><strong>Effective Date:</strong> August 28, 2025</p>

    <h2>Purpose</h2>
    <p>WalletWise is a personal finance and expense-tracking application designed to help users manage budgets, track transactions, and monitor financial goals effectively. It is intended for personal financial management only and not for commercial resale.</p>

    <h2>Developer</h2>
    <p><strong>Name:</strong> Tatiparthi Lavanya</p>
    <p><strong>Email:</strong> tlavanya07052005@gmial.com</p>

    <h2>Data Collection</h2>
    <ul>
      <li><strong>Personal Information:</strong> Name, Email</li>
      <li><strong>Financial Data:</strong> User-provided expense details, budget goals, and transaction history</li>
    </ul>

    <h2>Data Usage</h2>
    <p>Collected data is used solely to provide and enhance WalletWise features, such as budget tracking, personalized insights, and financial summaries. User data will <strong>not</strong> be sold, shared, or disclosed to third parties.</p>

    <h2>Data Storage</h2>
    <p>User data is securely stored in the WalletWise database and used only within the app for finance management purposes.</p>

    <h2>Third Party Access</h2>
    <p>No third parties have access to user personal or financial data.</p>

    <h2>User Rights</h2>
    <ul>
      <li><strong>Access:</strong> Users can request access to their stored data.</li>
      <li><strong>Delete:</strong> Users can request deletion of their data at any time via the app or by contacting support.</li>
    </ul>

    <h2>Security</h2>
    <p>WalletWise implements strong technical and organizational measures to safeguard user data against unauthorized access, misuse, or disclosure.</p>

    <h2>Contact</h2>
    <p>For any questions or concerns regarding this Privacy Policy, please contact:</p>
    <p><strong>Email:</strong> tlavanya07052005@gmial.com</p>
  </div>
</body>
</html>
